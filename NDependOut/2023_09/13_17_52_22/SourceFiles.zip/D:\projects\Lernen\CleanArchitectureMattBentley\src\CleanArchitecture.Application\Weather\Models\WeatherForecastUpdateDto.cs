﻿namespace CleanArchitecture.Application.Weather.Models
{
    public sealed class WeatherForecastUpdateDto
    {
        public DateTime Date { get; set; }
    }
}